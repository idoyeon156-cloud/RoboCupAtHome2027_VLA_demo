from setuptools import setup
from glob import glob

setup(
    name="piper_collision_guard", version="0.1.0",
    packages=["piper_collision_guard"],
    data_files=[
        ("share/ament_index/resource_index/packages", ["resource/piper_collision_guard"]),
        ("share/piper_collision_guard", ["package.xml", "README.md", "VISUAL_DEMO.md"]),
        ("share/piper_collision_guard/config", glob("config/*.yaml")),
        ("share/piper_collision_guard/config", glob("config/*.rviz")),
        ("share/piper_collision_guard/launch", glob("launch/*.launch.py")),
    ],
    install_requires=["setuptools", "numpy", "scipy>=1.10,<2"],
    zip_safe=True,
    maintainer="idoyeon156-cloud",
    maintainer_email="275096685+idoyeon156-cloud@users.noreply.github.com",
    description="Pinocchio point-distance monitor and position-command gate for dual Piper",
    license="MIT",
    entry_points={"console_scripts": [
        "moveit_box_editor = piper_collision_guard.box_editor:main",
        "collision_degree_sliders = piper_collision_guard.degree_gui:main",
        "collision_guard = piper_collision_guard.node:main",
        "cereal_pour = piper_collision_guard.cereal_pour:main",
        "cereal_preview = piper_collision_guard.cereal_preview:main",
        "cereal_simulated_driver = piper_collision_guard.simulation_driver:main",
        "collision_limit_visual_demo = piper_collision_guard.preview:main",
    ]},
)
