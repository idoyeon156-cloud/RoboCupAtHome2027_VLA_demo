# 조인트 거리 실물용 — 수정 가능한 버전

이 ZIP에는 설정, 원본 URDF/STL, 다면체 재생성 도구 및 시뮬·실물용 실행 경로가 함께 들어 있습니다.
압축을 푼 뒤 이 안내 파일이 있는 폴더에서 아래 순서로 실행합니다.

## 최초 환경 준비 (Ubuntu 22.04 / ROS 2 Humble)

```bash
sudo apt install ros-humble-moveit ros-humble-rviz2 ros-humble-robot-state-publisher ros-humble-joint-state-publisher-gui ros-humble-tf2-ros ros-humble-python-qt-binding python3-venv python3-colcon-common-extensions
source /opt/ros/humble/setup.bash
python3 -m venv --system-site-packages .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

## 실행

```bash
bash run_distance_real.sh
```

실행기가 이 폴더 안에 자동으로 빌드합니다. 실제 Piper 드라이버는 실행하지 않습니다.
실물용의 기본값은 감시 모드입니다. 확인 후 명령 전달 활성화는 README.md를 참고하세요.

## 변경 반영

1. config/robot.yaml에서 설치 위치·각도·최대 개방 폭·마운트 형상을 수정합니다.
2. 부품 외형이 바뀌면 model/dual_piper.source.urdf와 해당 원본 STL을 수정합니다.
3. 아래 명령으로 새 다면체와 관련 모델을 함께 생성한 뒤 재실행합니다.

```bash
.venv/bin/python tools/prepare_model.py
bash run_distance_real.sh
```

시뮬 입력은 °/mm, 설정의 rpy는 rad, 길이는 m입니다. 상세 수정 항목은 README.md에 있습니다.
각 ZIP은 독립된 작업 공간입니다. 여러 ZIP을 따로 쓰면 수정한 설정·원본 모델을 각 작업 공간에도 동일하게 적용하고 재생성해야 합니다.
한 작업 공간 안에서는 시뮬과 실물용이 같은 생성 모델을 공유합니다. 시뮬은 하나씩 실행하세요.
